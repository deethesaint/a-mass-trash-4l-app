@extends('layouts.app')
@section('content')
<div class="grid grid-cols- gap-2">
    
</div>
@endsection